package com.example.harikrishna.firebasetestproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class FifthActivity extends AppCompatActivity {

    TextView txt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);
        txt =(TextView)findViewById(R.id.textMail);
        final Intent intent = getIntent();
        txt.setText("User Mail ID: "+intent.getStringExtra("mail"));
        Toast.makeText(getApplicationContext(),"Success..!",Toast.LENGTH_SHORT).show();
    }
}
