package com.example.harikrishna.firebasetestproject;

/**
 * Created by HariKrishna on 28-12-2017.
 */

public class Person {

    private String idPerson;
    private String namePerson;
    private String numberPerson;
    private String emailPerson;


    public Person(){

    }

    public Person(String idPerson, String namePerson, String numberPerson, String emailPerson) {
        this.idPerson = idPerson;
        this.namePerson = namePerson;
        this.numberPerson = numberPerson;
        this.emailPerson = emailPerson;
    }

    public String getIdPerson() {
        return idPerson;
    }

    public String getNamePerson() {
        return namePerson;
    }

    public String getNumberPerson() {
        return numberPerson;
    }

    public String getEmailPerson() {
        return emailPerson;
    }
}
