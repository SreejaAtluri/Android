package com.example.harikrishna.firebasetestproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView txtName;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtName = (TextView)findViewById(R.id.textRecieve);
        final Intent intent = getIntent();
        txtName.setText("User Name: "+intent.getStringExtra("name"));
      //  txtName = (TextView)findViewById(R.i);
      //  txtName = (TextView)findViewById(R.id.textName)
        btn = (Button)findViewById(R.id.btnNext);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = intent.getStringExtra("id");

                String num = intent.getStringExtra("number");

                String mail = intent.getStringExtra("mail");

                startActivity(new Intent(getApplicationContext(),ThirdActivity.class).putExtra("id",id).putExtra("number",num).putExtra("mail",mail));
                finish();
            }
        });

    }
}
