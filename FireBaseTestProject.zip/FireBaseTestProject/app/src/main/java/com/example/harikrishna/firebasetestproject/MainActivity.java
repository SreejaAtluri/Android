package com.example.harikrishna.firebasetestproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {


    EditText edtTextid,edtTextName, edtTextNumber,edtTextMail;
    Button btnSendDataToServer;
    TextView txtReceive;
    FirebaseDatabase database;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtTextid = (EditText)findViewById(R.id.editID);
        edtTextName = (EditText) findViewById(R.id.editUserName);
        edtTextNumber = (EditText) findViewById(R.id.editPhoneNumber);
        edtTextMail = (EditText)findViewById(R.id.editMail);

        btnSendDataToServer = (Button) findViewById(R.id.btnSubmit);

        //txtReceive = (TextView) findViewById(R.id.textReceiveData);

        database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference();
        btnSendDataToServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Person person = new Person(edtTextid.getText().toString(),edtTextName.getText().toString(), edtTextNumber.getText().toString(),edtTextMail.getText().toString());

                databaseReference.child(person.getNumberPerson()).setValue(person);


                startActivity(new Intent(MainActivity.this,SecondActivity.class).putExtra("id",person.getIdPerson()).putExtra("name",person.getNamePerson()).putExtra("number",person.getNumberPerson()).putExtra("mail",person.getEmailPerson()));

                finish();

            }
        });
        // Read from the database
       /* databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String users="";
                for(DataSnapshot childs:dataSnapshot.getChildren()) {
                     Person value = childs.getValue(Person.class);
                     users += value.getNamePerson()+"\n";
                    // Log.d(TAG, "Value is: " + value);
                }
                txtReceive.setText(users);


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
               // Log.w(TAG, "Failed to read value.", error.toException());
            }
        });*/
       }
}