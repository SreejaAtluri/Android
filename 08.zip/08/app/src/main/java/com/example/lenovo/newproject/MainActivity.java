package com.example.lenovo.newproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    FirebaseDatabase database;
    DatabaseReference myRef;
    EditText name,id,phone,email;
    Button login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Write a message to the database
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("person");

        name= (EditText)findViewById(R.id.editText);
        id= (EditText)findViewById(R.id.editText2);
        phone= (EditText)findViewById(R.id.editText3);
        email= (EditText)findViewById(R.id.editText4);
        login=(Button)findViewById(R.id.button2);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PersonalDetails pd=new PersonalDetails(name.getText().toString(),
                        id.getText().toString(),phone.getText().toString(),
                        email.getText().toString());
                myRef.setValue(pd);
                startActivity(new Intent(MainActivity.this,FirstActivity.class));
            }
        });

    }

}
